from django.apps import AppConfig


class SchportalConfig(AppConfig):
    name = 'schPortal'
