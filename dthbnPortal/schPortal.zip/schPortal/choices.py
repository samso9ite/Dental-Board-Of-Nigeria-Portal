gender  = [
     ('', '--- Please Select ---') ,('Male', 'Male'), ('Female', 'Female')
]

year = [
     ('', '--- Please Select ---') ,('2019', '2019'), ('2020', '2020'), ('2021', '2021'), ('2022', '2022'), ('2023', '2023'), ('2024', '2024'), ('2025', '2025'),
    ('2026', '2026'),('2027', '2027'), ('2028', '2028'), ('2029', '2029'),('2030', '2030')
    
]

marital_status = [
    ('', '--- Please Select ---') ,('Single', 'Single'), ('Married', 'Married'), ('Divorced', 'Divorced')
]

cadre = [
     ('', '--- Please Select ---') ,('Dental Therapist', 'Dental Therapist'), ('Dental Surgery Technician', 'Dental Surgery Technician'),
    ('Dental Nurse', 'Dental Nurse'), ('Dental Therapist(abr)', ' Dental Therapist(abr)')
]

religion = [
   ('', '--- Please Select ---') , ('Christian', 'Christian'), ('Muslim', 'Muslim'), ('Others', 'Others')
]
num_sitting = [
    ('', '--- Please Select ---'), ('1', '1'), ('2', '2')
]

exam_type = [
     ('', '--- Please Select ---') ,('WAEC', 'WACE'), ('GCE', 'GCE'), ('NECO', 'NECO'), ('NABTEB', 'NABTEB')
]

exam_grade = [
     ('', '--- Please Select ---') ,('A1', 'A1'), ('B2', 'B2'), ('B3', 'B3'), ('C4', 'C4'), ('C5', 'C5'), ('C6', 'C6'), ('D7', 'D7'), ('E8', 'E8'),
    ('F9', 'F9')
]

subject = [
     ('', '--- Please Select ---') ,('Mathematics', 'Mathematics'), ('English', 'English'), ('Biology', 'Biology'), ('Agricultural Science', 'Agricultural Science'),
    ('Physics', 'Physics'), ('Chemistry', 'Chemistry'), ('Further Mathematics', 'Further Mathematics'), 
    ('Civic Education', 'Civic Education'),  ('Economics', 'Economics'), ('C.R.K', 'C.R.K'), ('I.R.K', 'I.R.S')
]

state = [
    ('','--- Please Select ---'), ('Abia', 'Abia'),('Adamawa', 'Adamawa'), ('Akwa Ibom', 'Akwa Ibom'), ('Anambra', 'Anambra'), ('Bauchi', 'Bauchi'), ('Bayelsa', 'Bayelsa'),
    ('Benue', 'Benue'), ('Borno', 'Borno'), ('Cross River', 'Cross River'), ('Delta', 'Delta'), ('Ebonyi', 'Ebonyi'), ('Edo', 'Edo'), ('Ekiti', 'Ekiti'), ('Enugu', 'Enugu'),
    ('Gombe', 'Gombe'), ('Delta', 'Delta'), ('Jigawa', 'Jigawa'), ('Kaduna', 'Kaduna'), ('Kano', 'Kano'), ('Katsina', 'Katsina'), ('Kebbi', 'Kebbi'), ('Kogi', 'Kogi'), ('Kwara', 'Kwara'),
    ('Lagos', 'Lagos'), ('Nasarawa', 'Nasarawa'), ('Niger', 'Niger'), ('Ogun', 'Ogun'), ('Ondo', 'Ondo'), ('Osun', 'Osun'), ('Oyo', 'Oyo'), ('Plateau', 'Plateau'),
    ('Rivers', 'Rivers'), ('Sokoto', 'Sokoto'), ('Taraba', 'Taraba'), ('Yobe', 'Yobe'), ('Kwara', 'Kwara'), ('Zamfara', 'Zamfara')
]

exam_sitting = [
    ('', '--- Please Select ---'), ('1', '1'), ('2', '2')
]
